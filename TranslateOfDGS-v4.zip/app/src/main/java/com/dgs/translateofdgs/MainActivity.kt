package com.dgs.translateofdgs

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TranslateDgsApp() }
    }
}

private enum class Screen { HOME, TEXT, PHOTO, CAMERA, SCREEN, VOICE, DIALOGUE, HISTORY, SETTINGS }
private data class Language(val trName: String, val enName: String, val code: String, val localeTag: String)
private data class Entry(val src: String, val tr: String, val photo: Boolean, val time: Long)
private data class DialogueTurn(val speakerA: Boolean, val original: String, val translated: String, val fromLabel: String, val toLabel: String)
private class Pal(
    val bg: Color, val card: Color, val border: Color, val ink: Color,
    val muted: Color, val tq: Color, val dark: Boolean,
)

private val darkPal = Pal(Color(0xFF050B0E), Color(0xFF0E1A1F), Color(0xFF1F3A40), Color.White, Color(0xFF9CB4BA), Color(0xFF16E0D3), true)
private val lightPal = Pal(Color(0xFFF4FAFA), Color.White, Color(0xFFCDE9E7), Color(0xFF12343A), Color(0xFF607A80), Color(0xFF0FB5AB), false)
private val onTq = Color(0xFF031316)

// En çok konuşulan 20 önemli dil (Türkçe ve İngilizce arayüz isimleriyle)
private val langs = listOf(
    Language("Türkçe", "Turkish", "tr", "tr-TR"),
    Language("İngilizce", "English", "en", "en-US"),
    Language("Çince (Mandarin)", "Chinese (Mandarin)", "zh-CN", "zh-CN"),
    Language("Hintçe", "Hindi", "hi", "hi-IN"),
    Language("İspanyolca", "Spanish", "es", "es-ES"),
    Language("Fransızca", "French", "fr", "fr-FR"),
    Language("Arapça", "Arabic", "ar", "ar-SA"),
    Language("Bengalce", "Bengali", "bn", "bn-BD"),
    Language("Rusça", "Russian", "ru", "ru-RU"),
    Language("Portekizce", "Portuguese", "pt", "pt-PT"),
    Language("Urduca", "Urdu", "ur", "ur-PK"),
    Language("Endonezce", "Indonesian", "id", "id-ID"),
    Language("Almanca", "German", "de", "de-DE"),
    Language("Japonca", "Japanese", "ja", "ja-JP"),
    Language("Svahili", "Swahili", "sw", "sw-KE"),
    Language("Marathi", "Marathi", "mr", "mr-IN"),
    Language("Telugu", "Telugu", "te", "te-IN"),
    Language("Korece", "Korean", "ko", "ko-KR"),
    Language("İtalyanca", "Italian", "it", "it-IT"),
    Language("Felemenkçe", "Dutch", "nl", "nl-NL"),
)

private val regions = listOf(
    "Türkiye (TR)", "Avrupa (EU)", "Amerika Birleşik Devletleri (US)",
    "Birleşik Krallık (UK)", "Rusya & BDT (RU)", "Orta Doğu (MENA)", "Asya-Pasifik (APAC)"
)

private fun langDisplayName(l: Language, appLang: String): String =
    if (appLang == "tr") l.trName else l.enName

private fun t(appLang: String, tr: String, en: String): String =
    if (appLang == "tr") tr else en

private fun loadHistory(ctx: Context): List<Entry> {
    val raw = ctx.getSharedPreferences("dgs_prefs", 0).getString("history", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getString("s"), o.getString("t"), o.optBoolean("p"), o.optLong("d"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveHistory(ctx: Context, list: List<Entry>) {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("s", it.src).put("t", it.tr).put("p", it.photo).put("d", it.time)) }
    ctx.getSharedPreferences("dgs_prefs", 0).edit().putString("history", arr.toString()).apply()
}

private fun copyToClipboard(ctx: Context, text: String, appLang: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Çeviri", text))
    Toast.makeText(ctx, t(appLang, "Kopyalandı", "Copied"), Toast.LENGTH_SHORT).show()
}

private fun pasteFromClipboard(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip
    if (clip != null && clip.itemCount > 0) {
        return clip.getItemAt(0).coerceToText(ctx)?.toString() ?: ""
    }
    return ""
}

@Composable
private fun TranslateDgsApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("dgs_prefs", 0) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var textInput by remember { mutableStateOf("") }
    var translated by remember { mutableStateOf("") }
    var recognized by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }

    // Varsayılan Kaynak: Türkçe, Hedef: İngilizce
    var source by remember { mutableStateOf(langs[0]) }
    var target by remember { mutableStateOf(langs[1]) }

    var errorText by remember { mutableStateOf("") }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var appLang by remember { mutableStateOf(prefs.getString("app_lang", "tr") ?: "tr") }
    var selectedRegion by remember { mutableStateOf(prefs.getString("region", regions[0]) ?: regions[0]) }
    val history = remember { mutableStateListOf<Entry>().apply { addAll(loadHistory(context)) } }

    // Aksanlı Sesli Okuma (TTS) Motoru
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
            }
        }
        engine
    }
    DisposableEffect(Unit) {
        onDispose {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        }
    }

    fun speakText(text: String, localeTag: String) {
        if (text.isBlank()) return
        val engine = tts ?: return
        if (!ttsReady) {
            Toast.makeText(context, t(appLang, "Ses motoru hazırlanıyor...", "Speech engine preparing..."), Toast.LENGTH_SHORT).show()
            return
        }
        val locale = Locale.forLanguageTag(localeTag)
        val res = engine.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(
                context,
                t(appLang, "Bu dil için cihazda aksan paketi yüklü değil, varsayılan sesle okunuyor.", "Accent pack not installed on device, using default voice."),
                Toast.LENGTH_SHORT
            ).show()
        }
        engine.setSpeechRate(0.95f)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dgs_tts_${System.currentTimeMillis()}")
    }

    fun addEntry(src: String, tr: String, photo: Boolean) {
        if (src.isBlank() || tr.isBlank()) return
        if (history.isNotEmpty() && history.first().src == src && history.first().tr == tr) return
        history.add(0, Entry(src, tr, photo, System.currentTimeMillis()))
        while (history.size > 50) history.removeAt(history.size - 1)
        saveHistory(context, history.toList())
    }

    fun openScreen(s: Screen) {
        screen = s
        errorText = ""
        translated = ""
        recognized = ""
    }

    // Metin yazıldıkça anında otomatik çeviri (500ms debounce)
    LaunchedEffect(textInput, source, target, screen) {
        if (screen == Screen.TEXT) {
            val clean = textInput.trim()
            if (clean.isEmpty()) {
                translated = ""
                isBusy = false
            } else {
                delay(450)
                isBusy = true
                errorText = ""
                translateText(clean, source.code, target.code) { result, ok ->
                    translated = result
                    isBusy = false
                }
            }
        }
    }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            openScreen(Screen.PHOTO)
            isBusy = true
            try {
                val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) {
                    errorText = t(appLang, "Fotoğraf okunamadı.", "Could not read photo.")
                    isBusy = false
                } else runOcr(bitmap) { text ->
                    recognized = text
                    if (text.isBlank()) {
                        errorText = t(appLang, "Fotoğrafta yazı bulunamadı.", "No text found in photo.")
                        isBusy = false
                    } else translateText(text, source.code, target.code) { result, ok ->
                        translated = result
                        isBusy = false
                        if (ok) addEntry(text, result, true)
                    }
                }
            } catch (e: Exception) {
                errorText = e.localizedMessage ?: t(appLang, "Fotoğraf açılamadı.", "Could not open photo.")
                isBusy = false
            }
        }
    }

    var pendingVoiceScreen by remember { mutableStateOf(Screen.VOICE) }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScreen(pendingVoiceScreen)
        else errorText = t(appLang, "Sesli çeviri için mikrofon izni gerekli.", "Microphone permission is required for voice translation.")
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScreen(Screen.CAMERA)
        else errorText = t(appLang, "Kamera izni olmadan kamera çevirisi açılamaz.", "Camera permission is required.")
    }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val svc = Intent(context, ScreenTranslateService::class.java)
                .putExtra("code", res.resultCode)
                .putExtra("data", data)
                .putExtra("from", source.code)
                .putExtra("to", target.code)
            ContextCompat.startForegroundService(context, svc)
            Toast.makeText(
                context,
                t(appLang, "Ekran çevirisi açıldı. Çevirmek istediğin uygulamaya geç.", "Screen translation started. Switch to the app you want to translate."),
                Toast.LENGTH_LONG
            ).show()
            (context as? Activity)?.moveTaskToBack(true)
        } else {
            errorText = t(appLang, "Ekran yakalama izni verilmedi.", "Screen capture permission denied.")
        }
    }

    fun startScreenTranslation() {
        errorText = ""
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(
                context,
                t(appLang, "Önce 'Diğer uygulamaların üzerinde göster' iznini aç, sonra geri dönüp tekrar başlat.", "Enable 'Display over other apps' permission first, then return and start again."),
                Toast.LENGTH_LONG
            ).show()
            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        } else {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    val p = if (darkMode) darkPal else lightPal
    val scheme = if (darkMode) darkColorScheme(primary = p.tq, background = p.bg, surface = p.card)
    else lightColorScheme(primary = p.tq, background = p.bg, surface = p.card)

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = p.bg,
            bottomBar = {
                val tab = when (screen) { Screen.HISTORY -> 1; Screen.SETTINGS -> 2; else -> 0 }
                NavigationBar(containerColor = p.bg) {
                    NavItem(p, tab == 0, Icons.Outlined.Home, t(appLang, "Ana sayfa", "Home")) { openScreen(Screen.HOME) }
                    NavItem(p, tab == 1, Icons.Outlined.History, t(appLang, "Geçmiş", "History")) { openScreen(Screen.HISTORY) }
                    NavItem(p, tab == 2, Icons.Outlined.Settings, t(appLang, "Ayarlar", "Settings")) { openScreen(Screen.SETTINGS) }
                }
            },
        ) { inner ->
            Column(
                Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        p = p, appLang = appLang, history = history,
                        onText = { openScreen(Screen.TEXT) },
                        onPhoto = { gallery.launch("image/*") },
                        onCamera = { cameraPermission.launch(Manifest.permission.CAMERA) },
                        onScreen = { openScreen(Screen.SCREEN) },
                        onVoice = {
                            pendingVoiceScreen = Screen.VOICE
                            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onDialogue = {
                            pendingVoiceScreen = Screen.DIALOGUE
                            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onStartScreen = { startScreenTranslation() },
                        onSettings = { openScreen(Screen.SETTINGS) },
                        onHistory = { openScreen(Screen.HISTORY) },
                        onCopy = { copyToClipboard(context, it, appLang) },
                        onSpeak = { txt -> speakText(txt, target.localeTag) },
                    )

                    Screen.TEXT -> {
                        ScreenTitle(p, t(appLang, "Metin çevirisi", "Text translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = {
                                val tmp = source
                                source = target
                                target = tmp
                                if (translated.isNotBlank()) {
                                    val oldTr = translated
                                    textInput = oldTr
                                }
                            }
                        )
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(t(appLang, "Çevrilecek metin (Otomatik çevrilir)", "Text to translate (Auto-translates)")) },
                            minLines = 4,
                            trailingIcon = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = {
                                        val pasted = pasteFromClipboard(context)
                                        if (pasted.isNotBlank()) {
                                            textInput = pasted
                                        } else {
                                            Toast.makeText(context, t(appLang, "Panoda metin yok", "Clipboard is empty"), Toast.LENGTH_SHORT).show()
                                        }
                                    }) {
                                        Icon(Icons.Outlined.ContentPaste, contentDescription = t(appLang, "Yapıştır", "Paste"), tint = p.tq)
                                    }
                                    if (textInput.isNotBlank()) {
                                        IconButton(onClick = { speakText(textInput, source.localeTag) }) {
                                            Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = t(appLang, "Dinle", "Listen"), tint = p.muted)
                                        }
                                    }
                                }
                            }
                        )
                        PrimaryButton(p, t(appLang, "ÇEVİR VE GEÇMİŞE KAYDET", "TRANSLATE & SAVE"), isBusy, appLang) {
                            isBusy = true; errorText = ""
                            translateText(textInput, source.code, target.code) { result, ok ->
                                translated = result; isBusy = false
                                if (ok) addEntry(textInput, result, false)
                            }
                        }
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = {
                                    copyToClipboard(context, translated, appLang)
                                    addEntry(textInput, translated, false)
                                },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.PHOTO -> {
                        ScreenTitle(p, t(appLang, "Fotoğraf çevirisi", "Photo translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        PrimaryButton(p, t(appLang, "Galeriden fotoğraf seç", "Choose photo from gallery"), isBusy, appLang) { gallery.launch("image/*") }
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = { copyToClipboard(context, translated, appLang) },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.CAMERA -> {
                        ScreenTitle(p, t(appLang, "Kamera çevirisi", "Camera translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        CameraTranslator(
                            p = p,
                            appLang = appLang,
                            sourceCode = source.code,
                            targetCode = target.code,
                            onTranslated = { tr, orig ->
                                translated = tr
                                if (orig.isNotBlank() && tr.isNotBlank()) addEntry(orig, tr, true)
                            },
                            onBusy = { isBusy = it }
                        )
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = { copyToClipboard(context, translated, appLang) },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.VOICE -> {
                        ScreenTitle(p, t(appLang, "Sesli konuşma çevirisi", "Voice speech translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        VoiceTranslatorSection(
                            p = p,
                            appLang = appLang,
                            source = source,
                            target = target,
                            recognized = recognized,
                            translated = translated,
                            onRecognized = { recognized = it },
                            onTranslated = { tr ->
                                translated = tr
                                if (recognized.isNotBlank() && tr.isNotBlank()) {
                                    addEntry(recognized, tr, false)
                                    speakText(tr, target.localeTag)
                                }
                            },
                            onBusy = { isBusy = it },
                            onCopy = { copyToClipboard(context, it, appLang) },
                            onSpeakSource = { speakText(recognized, source.localeTag) },
                            onSpeakTarget = { speakText(translated, target.localeTag) }
                        )
                    }

                    Screen.DIALOGUE -> {
                        ScreenTitle(p, t(appLang, "Canlı diyalog (2 Kişi)", "Live dialogue (2 People)"), appLang) { screen = Screen.HOME }
                        DialogueTranslatorSection(
                            p = p,
                            appLang = appLang,
                            langA = source,
                            langB = target,
                            onLangA = { source = it },
                            onLangB = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp },
                            onSpeak = { txt, loc -> speakText(txt, loc) },
                            onCopy = { copyToClipboard(context, it, appLang) },
                            onSaveHistory = { orig, tr -> addEntry(orig, tr, false) }
                        )
                    }

                    Screen.SCREEN -> {
                        ScreenTitle(p, t(appLang, "Ekran çevirisi", "Screen translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Nasıl çalışır", "How it works"), color = p.ink, fontWeight = FontWeight.Bold)
                            Text(
                                t(
                                    appLang,
                                    "1. Başlat'a bas ve istenen izinleri ver.\n2. Çevirmek istediğin uygulamaya veya oyuna geç.\n3. Yüzen paneldeki Çevir'e bas; ekrandaki yazılar seçtiğin hedef dile çevrilir ve ekranda sabit kalır.\n4. Oto'yu açarsan ekran değiştiğinde otomatik yenilenir, Kapat (✕) tuşuna basınca ekrandaki tüm yazılar anında temizlenir.",
                                    "1. Tap Start and grant permissions.\n2. Switch to the app or game you want to translate.\n3. Tap Translate on the floating bar; screen texts are translated and stay visible until you clear or close.\n4. Enable Auto for continuous updates, tap ✕ to cleanly close everything."
                                ),
                                color = p.muted,
                            )
                        }
                        PrimaryButton(p, t(appLang, "Ekran çevirisini başlat", "Start screen translation"), false, appLang) { startScreenTranslation() }
                        OutlinedButton(
                            onClick = { context.stopService(Intent(context, ScreenTranslateService::class.java)) },
                            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp),
                            border = BorderStroke(1.dp, p.tq),
                        ) { Text(t(appLang, "Durdur", "Stop"), color = p.tq) }
                    }

                    Screen.HISTORY -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.History, null, tint = p.tq)
                            Spacer(Modifier.width(8.dp))
                            Text(t(appLang, "Geçmiş", "History"), color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (history.isNotEmpty()) TextButton(onClick = { history.clear(); saveHistory(context, emptyList()) }) {
                                Text(t(appLang, "Temizle", "Clear"), color = p.tq)
                            }
                        }
                        if (history.isEmpty()) Text(t(appLang, "Henüz çeviri yok.", "No translations yet."), color = p.muted)
                        history.forEach { entry ->
                            HistoryRow(
                                p = p,
                                e = entry,
                                onCopy = { txt -> copyToClipboard(context, txt, appLang) },
                                onSpeak = { txt -> speakText(txt, target.localeTag) }
                            )
                        }
                    }

                    Screen.SETTINGS -> {
                        Text(t(appLang, "Ayarlar", "Settings"), color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)

                        // Uygulama Dili Seçimi (Türkçe ile başlar)
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Uygulama dili seçin", "Select app language"), color = p.ink, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        appLang = "tr"
                                        prefs.edit().putString("app_lang", "tr").apply()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(if (appLang == "tr") 2.dp else 1.dp, if (appLang == "tr") p.tq else p.border),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (appLang == "tr") p.tq.copy(alpha = 0.15f) else Color.Transparent
                                    )
                                ) { Text("Türkçe (Varsayılan)", color = p.ink, fontWeight = if (appLang == "tr") FontWeight.Bold else FontWeight.Normal) }

                                OutlinedButton(
                                    onClick = {
                                        appLang = "en"
                                        prefs.edit().putString("app_lang", "en").apply()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(if (appLang == "en") 2.dp else 1.dp, if (appLang == "en") p.tq else p.border),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (appLang == "en") p.tq.copy(alpha = 0.15f) else Color.Transparent
                                    )
                                ) { Text("English", color = p.ink, fontWeight = if (appLang == "en") FontWeight.Bold else FontWeight.Normal) }
                            }
                        }

                        // Bölge Seçimi
                        var regionExpanded by remember { mutableStateOf(false) }
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Bölge seçimi", "Region selection"), color = p.ink, fontWeight = FontWeight.Bold)
                            Text(
                                t(appLang, "Sesli okuma aksanı ve çeviri sunucu bölgesini optimize eder.", "Optimizes speech accent and translation server region."),
                                color = p.muted, fontSize = 12.sp
                            )
                            Box {
                                OutlinedButton(
                                    onClick = { regionExpanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, p.tq)
                                ) {
                                    Text(selectedRegion, color = p.ink, modifier = Modifier.weight(1f))
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.tq)
                                }
                                DropdownMenu(expanded = regionExpanded, onDismissRequest = { regionExpanded = false }) {
                                    regions.forEach { reg ->
                                        DropdownMenuItem(
                                            text = { Text(reg) },
                                            onClick = {
                                                selectedRegion = reg
                                                prefs.edit().putString("region", reg).apply()
                                                regionExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Görünüm
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                        ) {
                            Text(t(appLang, "Görünüm", "Appearance"), color = p.ink, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (darkMode) t(appLang, "Karanlık mod", "Dark mode") else t(appLang, "Aydınlık mod", "Light mode"),
                                    color = p.muted, modifier = Modifier.weight(1f)
                                )
                                Switch(checked = darkMode, onCheckedChange = {
                                    darkMode = it
                                    prefs.edit().putBoolean("dark_mode", it).apply()
                                })
                            }
                        }

                        ContactCard(p, appLang)
                    }
                }
                if (isBusy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.tq)
                if (errorText.isNotBlank()) Text(errorText, color = Color(0xFFFF8B8B))
                Text(
                    "Telif Hakkı © 2026 Denizgokmersogut - Tüm Hakları Saklıdır.",
                    color = p.muted, fontSize = 11.sp,
                )
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(p: Pal, selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = p.tq, selectedTextColor = p.tq,
            unselectedIconColor = p.muted, unselectedTextColor = p.muted,
            indicatorColor = Color.Transparent,
        ),
    )
}

@Composable
private fun HomeScreen(
    p: Pal, appLang: String, history: List<Entry>,
    onText: () -> Unit, onPhoto: () -> Unit, onCamera: () -> Unit, onScreen: () -> Unit,
    onVoice: () -> Unit, onDialogue: () -> Unit,
    onStartScreen: () -> Unit, onSettings: () -> Unit, onHistory: () -> Unit,
    onCopy: (String) -> Unit, onSpeak: (String) -> Unit,
) {
    Box(Modifier.fillMaxWidth().height(120.dp)) {
        WaveBackground(p, Modifier.matchParentSize())
        Row(Modifier.fillMaxWidth().align(Alignment.TopCenter), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.dgs_logo), contentDescription = null, modifier = Modifier.size(84.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Translate", color = p.ink, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                Text("of DGS", color = p.tq, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                Text(t(appLang, "Akıllı çeviri merkezi", "Smart translation hub"), color = p.muted, fontSize = 13.sp)
                Box(Modifier.padding(top = 4.dp).width(60.dp).height(2.dp).background(p.tq))
            }
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, p.tq, RoundedCornerShape(12.dp)).clickable { onSettings() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Settings, contentDescription = t(appLang, "Ayarlar", "Settings"), tint = p.tq) }
        }
    }

    Box(
        Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(p.card, if (p.dark) Color(0xFF0A2A30) else Color(0xFFE2F7F5))))
            .border(1.dp, p.border, RoundedCornerShape(20.dp)).clickable { onText() },
    ) {
        Image(
            painterResource(R.drawable.dgs_globe), contentDescription = null,
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(190.dp),
            contentScale = ContentScale.Crop,
        )
        Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(64.dp).clip(RoundedCornerShape(2.dp)).background(p.tq))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(t(appLang, "Anında çevir", "Instant translate"), color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    t(appLang, "Dilediğin metni hızlıca\nkendi diline çevir", "Quickly translate any text\ninto your language"),
                    color = p.muted, fontSize = 14.sp
                )
            }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.Description, t(appLang, "Metin çevirisi", "Text translate"), Modifier.weight(1f), onText)
        TileCard(p, Icons.Outlined.PhotoCamera, t(appLang, "Kamera", "Camera"), Modifier.weight(1f), onCamera)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.ImageIcon, t(appLang, "Fotoğraf", "Photo"), Modifier.weight(1f), onPhoto)
        TileCard(p, Icons.Outlined.CropFree, t(appLang, "Ekran çevirisi", "Screen translate"), Modifier.weight(1f), onScreen)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.Mic, t(appLang, "Sesli çeviri", "Voice translate"), Modifier.weight(1f), onVoice)
        TileCard(p, Icons.Outlined.Forum, t(appLang, "Canlı diyalog", "Live dialogue"), Modifier.weight(1f), onDialogue)
    }

    Row(
        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(29.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF22E8E0), Color(0xFF12C9CC)))).clickable { onStartScreen() },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Outlined.CropFree, null, tint = onTq)
        Spacer(Modifier.width(10.dp))
        Text(t(appLang, "Ekran çevirisini başlat", "Start screen translation"), color = onTq, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Filled.PlayArrow, null, tint = onTq)
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.History, null, tint = p.tq)
        Spacer(Modifier.width(8.dp))
        Text(t(appLang, "Son çeviriler", "Recent translations"), color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Row(Modifier.clickable { onHistory() }, verticalAlignment = Alignment.CenterVertically) {
            Text(t(appLang, "Tümünü gör", "See all"), color = p.tq, fontSize = 14.sp)
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.tq)
        }
    }
    if (history.isEmpty()) Text(
        t(appLang, "Henüz çeviri yok. İlk çevirini yaptığında burada görünecek.", "No translations yet. They will appear here."),
        color = p.muted, fontSize = 13.sp
    )
    history.take(2).forEach { HistoryRow(p, it, onCopy, onSpeak) }

    ContactCard(p, appLang)
}

@Composable
private fun TileCard(p: Pal, icon: ImageVector, title: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp)).clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = p.tq, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.ink, fontWeight = FontWeight.Medium, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }
    }
}

@Composable
private fun HistoryRow(p: Pal, e: Entry, onCopy: (String) -> Unit, onSpeak: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (e.photo) Icons.Outlined.ImageIcon else Icons.Outlined.Description, null, tint = p.ink, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.src, color = p.ink, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text("→ ${e.tr}", color = p.tq, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
        IconButton(onClick = { onSpeak(e.tr) }) { Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.tq) }
        IconButton(onClick = { onCopy(e.tr) }) { Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted) }
    }
}

@Composable
private fun ContactCard(p: Pal, appLang: String) {
    val context = LocalContext.current
    fun openUrl(url: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) { }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).border(1.dp, p.tq, RoundedCornerShape(16.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Person, null, tint = p.muted, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(1.dp).height(44.dp).background(p.border))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(t(appLang, "Tasarım & Geliştirme", "Design & Development"), color = p.muted, fontSize = 11.sp)
            Text("Deniz Gökmer Söğüt", color = p.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(1.dp).height(44.dp).background(p.border))
        Spacer(Modifier.width(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(t(appLang, "Bize Ulaşın", "Contact Us"), color = p.muted, fontSize = 11.sp)
            Row(
                modifier = Modifier.clickable { openUrl("https://instagram.com/Denizgokmersogut") },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(12.dp).background(Color(0xFFE1306C), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Denizgokmersogut",
                    color = p.tq,
                    fontSize = 12.sp,
                    textDecoration = TextDecoration.Underline
                )
            }
            Row(
                modifier = Modifier.clickable { openUrl("https://t.me/Denizgokmersogut") },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(12.dp).background(Color(0xFF29A9EB), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Denizgokmersogut",
                    color = p.tq,
                    fontSize = 12.sp,
                    textDecoration = TextDecoration.Underline
                )
            }
        }
    }
}

@Composable
private fun ScreenTitle(p: Pal, title: String, appLang: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text(t(appLang, "‹ Geri", "‹ Back"), color = p.tq) }
        Text(title, color = p.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun PrimaryButton(p: Pal, title: String, loading: Boolean, appLang: String, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = !loading, modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(25.dp),
        colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq),
    ) { Text(if (loading) t(appLang, "İŞLENİYOR…", "PROCESSING…") else title, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ResultCard(p: Pal, title: String, content: String, onCopy: (() -> Unit)?, onSpeak: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(16.dp)).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.tq, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (onSpeak != null) {
                IconButton(onClick = onSpeak) {
                    Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Sesli Oku", tint = p.tq)
                }
            }
            if (onCopy != null) {
                IconButton(onClick = onCopy) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted)
                }
            }
        }
        Text(content, color = p.ink, fontSize = 16.sp)
    }
}

@Composable
private fun LangRow(
    p: Pal, appLang: String, source: Language, target: Language,
    onSource: (Language) -> Unit, onTarget: (Language) -> Unit, onSwap: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        LangPicker(p, appLang, t(appLang, "Kaynak", "From"), source, onSource, Modifier.weight(1f))
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(p.card)
                .border(1.dp, p.tq, CircleShape)
                .clickable { onSwap() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.SwapHoriz, contentDescription = t(appLang, "Dilleri değiştir", "Swap languages"), tint = p.tq)
        }
        LangPicker(p, appLang, t(appLang, "Hedef", "To"), target, onTarget, Modifier.weight(1f))
    }
}

@Composable
private fun LangPicker(p: Pal, appLang: String, label: String, selected: Language, onSelect: (Language) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, p.tq),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
        ) {
            Text(
                "$label: ${langDisplayName(selected, appLang)}",
                color = p.ink, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 360.dp)) {
            langs.forEach { l ->
                DropdownMenuItem(
                    text = { Text(langDisplayName(l, appLang)) },
                    onClick = { onSelect(l); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun VoiceTranslatorSection(
    p: Pal, appLang: String, source: Language, target: Language,
    recognized: String, translated: String,
    onRecognized: (String) -> Unit, onTranslated: (String) -> Unit,
    onBusy: (Boolean) -> Unit, onCopy: (String) -> Unit,
    onSpeakSource: () -> Unit, onSpeakTarget: () -> Unit,
) {
    val context = LocalContext.current
    var listening by remember { mutableStateOf(false) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        listening = false
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = matches?.firstOrNull()?.trim() ?: ""
            if (spoken.isNotBlank()) {
                onRecognized(spoken)
                onBusy(true)
                translateText(spoken, source.code, target.code) { tr, _ ->
                    onTranslated(tr)
                    onBusy(false)
                }
            }
        }
    }

    fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, source.localeTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "${langDisplayName(source, appLang)} ${t(appLang, "konuşun…", "speak…")}")
        }
        try {
            listening = true
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            listening = false
            Toast.makeText(context, t(appLang, "Cihazda ses tanıma servisi bulunamadı.", "Speech recognition not available."), Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(Color(0xFF22E8E0), Color(0xFF12C9CC))))
                .clickable { startListening() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Mic, contentDescription = "Konuş", tint = onTq, modifier = Modifier.size(42.dp))
        }
        Text(
            if (listening) t(appLang, "Dinleniyor…", "Listening…")
            else "${langDisplayName(source, appLang)} ${t(appLang, "konuşmak için mikrofona dokun", "tap mic to speak")}",
            color = p.ink, fontWeight = FontWeight.Bold
        )
        Text(
            "${t(appLang, "Otomatik çevrilecek dil:", "Will auto-translate to:")} ${langDisplayName(target, appLang)}",
            color = p.tq, fontSize = 13.sp
        )
    }

    if (recognized.isNotBlank()) {
        ResultCard(
            p = p,
            title = "${t(appLang, "Konuşulan", "Spoken")} (${langDisplayName(source, appLang)})",
            content = recognized,
            onCopy = { onCopy(recognized) },
            onSpeak = onSpeakSource
        )
    }
    if (translated.isNotBlank()) {
        ResultCard(
            p = p,
            title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
            content = translated,
            onCopy = { onCopy(translated) },
            onSpeak = onSpeakTarget
        )
    }
}

@Composable
private fun DialogueTranslatorSection(
    p: Pal, appLang: String,
    langA: Language, langB: Language,
    onLangA: (Language) -> Unit, onLangB: (Language) -> Unit, onSwap: () -> Unit,
    onSpeak: (String, String) -> Unit, onCopy: (String) -> Unit,
    onSaveHistory: (String, String) -> Unit,
) {
    val context = LocalContext.current
    val turns = remember { mutableStateListOf<DialogueTurn>() }
    var activeSpeakerA by remember { mutableStateOf(true) }

    val dialogueLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = matches?.firstOrNull()?.trim() ?: ""
            if (spoken.isNotBlank()) {
                val fromL = if (activeSpeakerA) langA else langB
                val toL = if (activeSpeakerA) langB else langA
                val speakerIsA = activeSpeakerA
                translateText(spoken, fromL.code, toL.code) { tr, ok ->
                    if (ok && tr.isNotBlank()) {
                        turns.add(
                            0,
                            DialogueTurn(
                                speakerA = speakerIsA,
                                original = spoken,
                                translated = tr,
                                fromLabel = langDisplayName(fromL, appLang),
                                toLabel = langDisplayName(toL, appLang)
                            )
                        )
                        onSaveHistory(spoken, tr)
                        onSpeak(tr, toL.localeTag)
                    }
                }
            }
        }
    }

    fun speakTurn(isA: Boolean) {
        activeSpeakerA = isA
        val speakLang = if (isA) langA else langB
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, speakLang.localeTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "${langDisplayName(speakLang, appLang)} ${t(appLang, "konuşun…", "speak…")}")
        }
        try {
            dialogueLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(context, t(appLang, "Ses tanıma açılamadı.", "Speech recognition failed."), Toast.LENGTH_SHORT).show()
        }
    }

    LangRow(p, appLang, langA, langB, onLangA, onLangB, onSwap)

    Text(
        t(
            appLang,
            "Sıra sıra konuşun: 1. Kişi konuştuğunda 2. Kişinin diline çevrilip sesli okunur; 2. Kişi konuştuğunda 1. Kişinin diline çevrilip sesli okunur.",
            "Take turns speaking: Person 1 translates & speaks in Person 2's language, and vice versa."
        ),
        color = p.muted, fontSize = 12.sp
    )

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = { speakTurn(true) },
            modifier = Modifier.weight(1f).height(64.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(t(appLang, "1. Kişi", "Person 1"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Text(langDisplayName(langA, appLang), fontSize = 12.sp)
            }
        }

        Button(
            onClick = { speakTurn(false) },
            modifier = Modifier.weight(1f).height(64.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1995AD), contentColor = Color.White)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(t(appLang, "2. Kişi", "Person 2"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Text(langDisplayName(langB, appLang), fontSize = 12.sp)
            }
        }
    }

    turns.forEach { turn ->
        val alignEnd = !turn.speakerA
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (turn.speakerA) p.card else p.tq.copy(alpha = 0.14f))
                .border(1.dp, if (turn.speakerA) p.border else p.tq, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${if (turn.speakerA) t(appLang, "1. Kişi", "Person 1") else t(appLang, "2. Kişi", "Person 2")} (${turn.fromLabel} → ${turn.toLabel})",
                    color = p.tq, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    val targetLocale = if (turn.speakerA) langB.localeTag else langA.localeTag
                    onSpeak(turn.translated, targetLocale)
                }) {
                    Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.tq)
                }
                IconButton(onClick = { onCopy(turn.translated) }) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted)
                }
            }
            Text(turn.original, color = p.muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text(turn.translated, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private fun runOcr(bitmap: Bitmap, callback: (String) -> Unit) {
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    recognizer.process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { result -> callback(result.text.trim()) }
        .addOnFailureListener { callback("") }
        .addOnCompleteListener { recognizer.close() }
}

internal fun translateText(text: String, from: String, to: String, callback: (String, Boolean) -> Unit) {
    val mainHandler = Handler(Looper.getMainLooper())
    if (text.isBlank()) { mainHandler.post { callback("", false) }; return }
    if (from == to) { mainHandler.post { callback(text, true) }; return }
    Thread {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$from&tl=$to&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val outer = JSONArray(response)
            val segments = outer.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i)
                if (seg != null && !seg.isNull(0)) {
                    sb.append(seg.getString(0))
                }
            }
            val result = sb.toString().trim()
            if (result.isNotEmpty()) {
                mainHandler.post { callback(result, true) }
            } else {
                mainHandler.post { callback("Çeviri sonucu boş döndü.", false) }
            }
        } catch (_: Exception) {
            mainHandler.post { callback("Çeviri hatası: İnternet bağlantını kontrol et.", false) }
        }
    }.start()
}

@OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
private fun CameraTranslator(
    p: Pal, appLang: String, sourceCode: String, targetCode: String,
    onTranslated: (String, String) -> Unit, onBusy: (Boolean) -> Unit,
) {
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val context = LocalContext.current
    var liveMode by remember { mutableStateOf(true) }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }

    DisposableEffect(Unit) {
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) { }
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analyzer = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                var lastRun = 0L
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                analyzer.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                    val now = System.currentTimeMillis()
                    if (liveMode && now - lastRun > 2200) {
                        lastRun = now
                        val media = imageProxy.image
                        if (media != null) {
                            val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
                            recognizer.process(input).addOnSuccessListener { result ->
                                val text = result.text.trim()
                                if (text.isNotBlank()) {
                                    onBusy(true)
                                    translateText(text, sourceCode, targetCode) { translated, _ ->
                                        onTranslated(translated, text)
                                        onBusy(false)
                                    }
                                }
                            }.addOnCompleteListener { imageProxy.close() }
                        } else imageProxy.close()
                    } else imageProxy.close()
                }
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analyzer)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp)),
    )

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = {
                liveMode = false
                onBusy(true)
                imageCapture.takePicture(
                    ContextCompat.getMainExecutor(context),
                    object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val media = image.image
                            if (media != null) {
                                val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                                val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                rec.process(input).addOnSuccessListener { res ->
                                    val txt = res.text.trim()
                                    if (txt.isBlank()) {
                                        onBusy(false)
                                        Toast.makeText(context, t(appLang, "Fotoğrafta yazı algılanamadı.", "No text detected."), Toast.LENGTH_SHORT).show()
                                    } else {
                                        translateText(txt, sourceCode, targetCode) { tr, _ ->
                                            onTranslated(tr, txt)
                                            onBusy(false)
                                        }
                                    }
                                }.addOnFailureListener {
                                    onBusy(false)
                                }.addOnCompleteListener {
                                    rec.close()
                                    image.close()
                                }
                            } else {
                                onBusy(false)
                                image.close()
                            }
                        }

                        override fun onError(exception: ImageCaptureException) {
                            onBusy(false)
                            Toast.makeText(context, t(appLang, "Fotoğraf çekilemedi.", "Failed to capture photo."), Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            },
            modifier = Modifier.weight(1f).height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq)
        ) {
            Icon(Icons.Outlined.PhotoCamera, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(t(appLang, "Fotoğraf Çek & Çevir", "Capture & Translate"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        OutlinedButton(
            onClick = { liveMode = !liveMode },
            modifier = Modifier.height(48.dp),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, p.tq)
        ) {
            Text(
                if (liveMode) t(appLang, "Canlı: Açık", "Live: On") else t(appLang, "Canlı: Kapalı", "Live: Off"),
                color = p.tq, fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun WaveBackground(p: Pal, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val glow = if (p.dark) 1f else 0.6f
        fun band(y0: Float, c1: Float, c2: Float, y1: Float, thick: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
                cubicTo(w * 0.65f, c2 + thick, w * 0.35f, c1 + thick, 0f, y0 + thick * 0.3f)
                close()
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w))
        }
        fun line(y0: Float, c1: Float, c2: Float, y1: Float, width: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w), style = Stroke(width = width))
        }
        band(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, h * 0.22f, 0.28f)
        band(h * 1.15f, h * 1.15f, h * 0.45f, h * 0.35f, h * 0.12f, 0.18f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 14f, 0.10f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 6f, 0.30f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 2.5f, 0.90f)
        line(h * 1.12f, h * 1.15f, h * 0.4f, h * 0.3f, 2f, 0.55f)
    }
}
